document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("registro");
    const contrasena = document.getElementById("contrasena");
    const confirmar = document.getElementById("confirmar_contrasena");

    form.addEventListener("submit", function (e) {
        // Validar que las contraseñas coincidan
        if (contrasena.value !== confirmar.value) {
            e.preventDefault(); // Detiene el envío
            alert("Las contraseñas no coinciden. Por favor, intenta nuevamente.");
        }
    });
});
