let mesActual = null;

function mostrarEventos(mes) {
  const contenedor = document.getElementById("eventos");
  contenedor.innerHTML = ""; // Limpiar

  let contenido = "";
  let mesesOrden = [
    "enero", "febrero", "marzo", "abril",
    "mayo", "junio", "julio", "agosto",
    "setiembre", "octubre", "noviembre", "diciembre"
  ];

  let indiceNuevo = mesesOrden.indexOf(mes);
  let indiceActual = mesesOrden.indexOf(mesActual);
  let direccion = "";

  if (mesActual !== null) {
    direccion = indiceNuevo > indiceActual ? "slide-in-right" : "slide-in-left";
  }

  mesActual = mes;

  if (mes === "mayo") {
    contenido = `
      <div class="evento ${direccion}">
        <img src="IMG/futbol.jpg" alt="Fútbol">
        <div><strong>Fútbol:</strong> 25 de mayo - Inscripciones abiertas</div>
      </div>
      <div class="evento ${direccion}">
        <img src="IMG/ajedrez.jpg" alt="Ajedrez">
        <div><strong>Torneo de Ajedrez:</strong> 28 de mayo - Sala C202</div>
      </div>
          
    `;
  } else if (mes === "junio") {
    contenido = `
      <div class="evento ${direccion}">
        <img src="IMG/voley.jpg" alt="Voley">
        <div><strong>Campeonato de Voley:</strong> 12 de junio - Auditorio principal</div>
      </div>
      <div class="evento ${direccion}">
        <img src="IMG/karate.jpg" alt="Karate">
        <div><strong>Competición de Karate:</strong> 13 de junio - Online vía Zoom</div>
      </div>
            <div class="evento ${direccion}">
        <img src="IMG/musica.jpg" alt="Musica">
        <div><strong>practica de instrumentos:</strong> 15 de junio - Auditorio principal</div>
      </div>
      <div class="evento ${direccion}">
        <img src="IMG/basquet.jpg" alt="Basquet">
        <div><strong>Competición de basquet:</strong> 18 de junio - Online vía Zoom</div>
      </div>
            <div class="evento ${direccion}">
        <img src="IMG/boxeo.jpg" alt="Boxeo">
        <div><strong>Campeonato de Boxeo:</strong> 20 de junio - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/baile.jpg" alt="baile">
        <div><strong>Competición de Baile:</strong> 22 de junio - Online vía Zoom</div>
        </div>
              <div class="evento ${direccion}">
        <img src="IMG/futbol.jpg" alt="Fútbol">
        <div><strong>Fútbol:</strong> 24 de junio - Inscripciones abiertas</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/ajedrez.jpg" alt="Ajedrez">
        <div><strong>Torneo de Ajedrez:</strong> 28 de junio - Sala C202</div>
      </div>

    `;
  }
  else if (mes === "julio") {
    contenido = `
      <div class="evento ${direccion}">
        <img src="IMG/musica.jpg" alt="Musica">
        <div><strong>practica de instrumentos:</strong> 5 de julio - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/basquet.jpg" alt="Basquet">
        <div><strong>Competición de basquet:</strong> 8 de julio - Online vía Zoom</div>
      </div>

            <div class="evento ${direccion}">
        <img src="IMG/boxeo.jpg" alt="Boxeo">
        <div><strong>Campeonato de Boxeo:</strong> 10 de julio - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/baile.jpg" alt="baile">
        <div><strong>Competición de Baile:</strong> 12 de julio - Online vía Zoom</div>
        </div>

              <div class="evento ${direccion}">
        <img src="IMG/voley.jpg" alt="Voley">
        <div><strong>Campeonato de Voley:</strong> 15 de julio - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/karate.jpg" alt="Karate">
        <div><strong>Competición de Karate:</strong> 17 de julio - Online vía Zoom</div>
      </div>

            <div class="evento ${direccion}">
        <img src="IMG/futbol.jpg" alt="Fútbol">
        <div><strong>Fútbol:</strong> 20 de julio - Inscripciones abiertas</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/ajedrez.jpg" alt="Ajedrez">
        <div><strong>Torneo de Ajedrez:</strong> 25 de julio - Sala C202</div>
      </div>
    `;
  }
  else if (mes === "agosto") {
    contenido = `
      <div class="evento ${direccion}">
        <img src="IMG/boxeo.jpg" alt="Boxeo">
        <div><strong>Campeonato de Boxeo:</strong> 3 de agosto - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/baile.jpg" alt="baile">
        <div><strong>Competición de Baile:</strong> 6 de agosto - Online vía Zoom</div>
        </div>

         <div class="evento ${direccion}">
        <img src="IMG/voley.jpg" alt="Voley">
        <div><strong>Campeonato de Voley:</strong> 8 de agosto - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/karate.jpg" alt="Karate">
        <div><strong>Competición de Karate:</strong> 10 de agosto - Online vía Zoom</div>
      </div>

            <div class="evento ${direccion}">
        <img src="IMG/musica.jpg" alt="Musica">
        <div><strong>practica de instrumentos:</strong> 13 de agosto - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/basquet.jpg" alt="Basquet">
        <div><strong>Competición de basquet:</strong> 15 de agosto - Online vía Zoom</div>
      </div>

            <div class="evento ${direccion}">
        <img src="IMG/boxeo.jpg" alt="Boxeo">
        <div><strong>Campeonato de Boxeo:</strong> 18 de agosto - Auditorio principal</div>
      </div>

      <div class="evento ${direccion}">
        <img src="IMG/baile.jpg" alt="baile">
        <div><strong>Competición de Baile:</strong> 20 de agosto - Online vía Zoom</div>
        </div>

              <div class="evento ${direccion}">
        <img src="IMG/futbol.jpg" alt="Fútbol">
        <div><strong>Fútbol:</strong> 25 de agosto - Inscripciones abiertas</div>
      </div>
      
      <div class="evento ${direccion}">
        <img src="IMG/ajedrez.jpg" alt="Ajedrez">
        <div><strong>Torneo de Ajedrez:</strong> 28 de agosto - Sala C202</div>
      </div>

    `;
  }
  
  else {
    contenido = `<p style="color:gray;">Eventos aún no disponibles para este mes.</p>`;
  }

  contenedor.innerHTML = contenido;

  const eventos = document.querySelectorAll(".evento");
  eventos.forEach((evento, index) => {
    evento.style.animationDelay = `${index * 0.1}s`;
  });
}
