let ultimoIndice = -1; // 👈 Variable fuera de la función para recordar el último índice

function generarEvento() {
    const display = document.getElementById('eventoSeleccionado');
    const eventosIds = ["cardsalud", "cardcinema", "cardcachimbos", "cardfilutp", "cardhackathonutp",
        "cardcosplayutp", "cardbandasutp", "cardecuputp", "cardemprendimientoutp", "cardfitopaez"];
    const mensajesEspera = [
        "Lanzando dados cuánticos...",
        "Generando números aleatorios...",
        "Aplicando la tercera ley de Newton...",
        "Calculando destino universitario...",
        "Sacudiendo la bola mágica..."
    ];

    const espera = mensajesEspera[Math.floor(Math.random() * mensajesEspera.length)];
    display.innerHTML = `<p style="font-style: italic; color: #555;">${espera}</p>`;

    setTimeout(() => {
        let nuevoIndice;
        do {
            nuevoIndice = Math.floor(Math.random() * eventosIds.length);
        } while (nuevoIndice == ultimoIndice);

        ultimoIndice = nuevoIndice;
        const randomId = eventosIds[nuevoIndice];
        const cardOriginal = document.getElementById(randomId);

        if (cardOriginal) {
            const titulo = cardOriginal.querySelector("h3")?.textContent || "Evento sin título";
            const imagen = cardOriginal.querySelector("img")?.src;

            // Crear nuevo mini-card
            const miniCard = document.createElement("div");
            miniCard.style.display = "flex";
            miniCard.style.flexDirection = "column";
            miniCard.style.alignItems = "center";
            miniCard.style.justifyContent = "center";
            miniCard.style.height = "100%";

            const tituloElemento = document.createElement("h4");
            tituloElemento.textContent = titulo;
            tituloElemento.style.marginBottom = "1rem";
            tituloElemento.style.color = "black";

            const imagenElemento = document.createElement("img");
            imagenElemento.src = imagen;
            imagenElemento.alt = titulo;
            imagenElemento.style.maxWidth = "100%";
            imagenElemento.style.maxHeight = "20rem";
            imagenElemento.style.borderRadius = "1rem";

            miniCard.appendChild(tituloElemento);
            miniCard.appendChild(imagenElemento);

            display.innerHTML = '';
            display.appendChild(miniCard);
        } else {
            display.innerHTML = "<p>Evento no encontrado.</p>";
        }
    }, 2000);
}

const track = document.querySelector('.carrusel-track');
const slides = document.querySelectorAll('.carrusel-slide');
let index = 0;

function moveSlide() {
    index = (index + 1) % slides.length;
    const slideWidth = slides[0].offsetWidth;
    track.style.transform = `translateX(-${slideWidth * index}px)`;
}

setInterval(moveSlide, 5000);
